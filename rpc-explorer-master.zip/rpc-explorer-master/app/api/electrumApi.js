var config = require("./../config.js");
var coins = require("../coins.js");
var utils = require("../utils.js");

var util = require('util');

// choose one of the below: RPC to a node, or mock data while testing
//var rpc = require("./rpcApi.js");
var rpc = require("./coreApi.js");
//var rpc = require("./mockApi.js");


var coinConfig = coins[config.coin];

const ElectrumClient = require('electrum-client');

var electrumClients = [];

function connectToServers() {
	return new Promise(function(resolve, reject) {
		var promises = [];

		for (var i = 0; i < config.electrumXServers.length; i++) {
			var { host, port, protocol } = config.electrumXServers[i];
			promises.push(connectToServer(host, port, protocol));
		}

		Promise.all(promises).then(function() {
			resolve();

		}).catch(function(err) {
			console.log("Error 120387rygxx231gwe40: " + err);

			reject(err);
		});
	});
}

function reconnectToServers() {
	return new Promise(function(resolve, reject) {
		for (var i = 0; i < electrumClients.length; i++) {
			electrumClients[i].close();
		}

		electrumClients = [];

		console.log("Reconnecting ElectrumX sockets...");

		connectToServers().then(function() {
			console.log("Done reconnecting ElectrumX sockets.");

			resolve();

		}).catch(function(err) {
			console.log("Error 317fh29y7fg3333: " + err);

			resolve();
		});
	});
}

function connectToServer(host, port, protocol) {
	return new Promise(function(resolve, reject) {
		console.log("Connecting to ElectrumX Server: " + host + ":" + port);
                
                if(global.electrumStandalone) {console.log("Electrum Standalone is LONG-specific"); resolve(); return;}

		// default protocol is 'tcp' if port is 50001, which is the default unencrypted port for electrumx
		var defaultProtocol = port === 50001 ? 'tcp' : 'tls';
		var electrumClient = new ElectrumClient(port, host, protocol || defaultProtocol);
		electrumClient.initElectrum({client:"btc-rpc-explorer-v1.1", version:"1.2"}).then(function(res) {
			console.log("Connected to ElectrumX Server: " + host + ":" + port + ", versions: " + JSON.stringify(res));

			electrumClients.push(electrumClient);

			resolve();

		}).catch(function(err) {
			console.log("Error 137rg023xx7gerfwdd: " + err + ", when trying to connect to ElectrumX server at " + host + ":" + port);

			reject(err);
		});
	});
	
}

function runOnServer(electrumClient, f) {
	return new Promise(function(resolve, reject) {
		f(electrumClient).then(function(result) {
			if (result.success) {
				resolve({result:result.response, server:electrumClient.host});

			} else {
				reject({error:result.error, server:electrumClient.host});
			}
		}).catch(function(err) {
			console.log("Error dif0e21qdh: " + err + ", host=" + electrumClient.host + ", port=" + electrumClient.port);

			reject(err);
		});
	});
}

function runOnAllServers(f) {
	return new Promise(function(resolve, reject) {
		var promises = [];

		for (var i = 0; i < electrumClients.length; i++) {
			promises.push(runOnServer(electrumClients[i], f));
		}

		Promise.all(promises).then(function(results) {
			resolve(results);

		}).catch(function(err) {
			reject(err);
		});
	});
}

function getAddressTxids(addrScripthash,address, start, end) {
	return new Promise(function(resolve, reject) {
            if(global.electrumStandalone ) { // RPC command getaddresstxids
                   rpc.getAddressTxids(address, start, end).then( (result) => {
            
                    if (result == null) reject(result);
                    else { // ElectrumX result
                        var ret = []; for (let i=0; i<result.length; i++) ret[i]={"tx_hash":result[i]};
                        
                        resolve( {result: ret} );
                    }
                    
                }).catch( (err) => {
                        reject(err);
                });   
            }
            else {
		runOnAllServers(function(electrumClient) {
			return electrumClient.blockchainScripthash_getHistory(addrScripthash);

		}).then(function(results) {
			if (addrScripthash == coinConfig.genesisCoinbaseOutputAddressScripthash) {
				for (var i = 0; i < results.length; i++) {
					results[i].result.unshift({tx_hash:coinConfig.genesisCoinbaseTransactionId, height:0});
				}
			}

			var first = results[0];
			var done = false;

			for (var i = 1; i < results.length; i++) {
				if (results[i].length != first.length) {
					resolve({conflictedResults:results});

					done = true;
				}
			}

			if (!done) {
				resolve(results[0]);
			}
		}).catch(function(err) {
			reject(err);
		});
            }
	});
}

function getAddressBalance(addrScripthash,address) {
	return new Promise(function(resolve, reject) {
            if(global.electrumStandalone) { // RPC command getaddressbalance
                
                rpc.getAddressBalance(address).then( (result) => {
            
                    if (result == null || result.balance == null) reject(result);
                    else { // ElectrumX result
                        var ret={ 
                            "confirmed": result.balance,
                            "unconfirmed": null,
                            "balance": result.balance,
                            "received": result.received,
                            //result: {"confirmed": result.balance.toString()}
                            result: {"confirmed": result.balance}
                        };
                        resolve(ret);
                    }
                    
                }).catch( (err) => {
                        reject(err);
                });                
            }
            else {
                runOnAllServers(function(electrumClient) {
                        return electrumClient.blockchainScripthash_getBalance(addrScripthash);

                }).then(function(results) {
                        if (addrScripthash == coinConfig.genesisCoinbaseOutputAddressScripthash) {
                                for (var i = 0; i < results.length; i++) {
                                        var coinbaseBlockReward = coinConfig.blockRewardFunction(0);
    				
                                        results[i].result.confirmed += (coinbaseBlockReward * coinConfig.baseCurrencyUnit.multiplier);
                                }
                        }

                        var first = results[0];
                        var done = false;

                        for (var i = 1; i < results.length; i++) {
                                if (results[i].confirmed != first.confirmed) {
                                        resolve({conflictedResults:results});

                                        done = true;
                                }
                        }

                        if (!done) {
                                resolve(results[0]);
                        }
                }).catch(function(err) {
                        reject(err);
                });
            }       
	});
}

module.exports = {
	connectToServers: connectToServers,
	reconnectToServers: reconnectToServers,
	getAddressTxids: getAddressTxids,
	getAddressBalance: getAddressBalance
};
